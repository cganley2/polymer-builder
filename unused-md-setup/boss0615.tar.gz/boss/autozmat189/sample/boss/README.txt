oplsaa_new.par --- contains I4 format atom types

% autozmat -i boss -o pdb -p oplsaa_new.par opt.zmat > opt.pdb

