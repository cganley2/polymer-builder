#ifndef __HASH_H_
#define __HASH_H_

extern int	LookUpStrTable(char *str);
extern void	CleanUpStrTable(void);
extern char	*GetStrValue(int n);

#endif
