Solvent Z-matrices and equilibrated in files are provided here
for several custom solvents. 
Some of these files use oplsua.par:
Check that the atom and dihedral type assignments in the Z-matrix
files match those in your par file.

The equilibrated in files for water droplets are also provided
with radii of 18, 20, 22 and 25 angstroms. These are up-to-date.

wslabin.512 is an equilibrated TIP4P water slab with 512 water molecules.
wslabin.1235 is an equilibrated TIP4P water slab with 1235 water molecules.
