Example of a binary solvent mixture -
50:50 v:v ethanol/water (TIP4P)

Runs 4M equilibration and 4M averaging;
time = 25 min on a 2 GHz PIV.
Volume is not equilibrated at this point;
execute cont.bat to continue.

See Appendix 1 in the BOSS User's Manual
on how to compute the numbers of molecules
to obtain the desired v:v ratio.

The bat files are for Windows.
