This job starts using t4pin, which is the same as the
wslabin.512 file in boss\solbox. The t4ppar file declares
the solvent origin as IN. One can start from scratch with a cubic
box by changing this to BOXES.
