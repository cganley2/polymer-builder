
This is a MC simulation of a droplet of TIP4P
water with a 12 Angstrom radius. In the cappar file, the
cap radius is specified and ICAPAT = atom 1 of the dummy
solute. The droplet is cut from a water box.           
A half-harmonic is applied at (CAPRAD+5) = 17 Angstroms
with a force constant of 1.5 kcal/mol-A^2.

Equilibration = 5M; Averaging = 5M configurations.
Time: 710 seconds on a 2.4 GHz Pentium IV.

You can display the plot file via
x capplte5

Results for a 25-A water droplet are in subdirectory 25.
30 M configurations were run.
