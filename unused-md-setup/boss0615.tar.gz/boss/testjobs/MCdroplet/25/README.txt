25-A TIP4P Water Cluster, RCUT = 9 A
# waters molecules = 2200
10 M equilibrartion, 20 M averaging
Time: 3-4 hours on a 2.4 GHz Pentium IV.
